export const environment = {
  production: true,
  base_url: 'http://ec2-3-234-142-108.compute-1.amazonaws.com:8080'
};
